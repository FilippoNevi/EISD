#!/bin/bash

docker build -t mentor_tools_base:20201130 .

