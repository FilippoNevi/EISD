#include <cmath>

void root(int a, int &b)
{
        b = sqrt(a);
}

