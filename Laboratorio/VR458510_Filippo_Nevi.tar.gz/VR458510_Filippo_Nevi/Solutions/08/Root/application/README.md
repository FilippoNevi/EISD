# Readme
## M6502 - SUPPORTED TYPES & DIMENSIONS
 * int 		        =>	16 bits
 * char		        =>	8 bits
 * uint8_t/int8_t  	=>	8 bits
 * uint16_t/int16_t	=>	16 bits
 * uint32_t/int32_t	=>	32 bits
 * float/double	    => 	not supported